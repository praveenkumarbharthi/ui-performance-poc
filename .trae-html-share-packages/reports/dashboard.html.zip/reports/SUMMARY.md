# UI Performance PoC - Run Summary

- **Run ID:** 2026-10-19T05-41-46-952
- **Generated:** 2026-10-19T05:42:27.837Z
- **Base URL:** https://www.saucedemo.com
- **Overall status:** passed
- **Failure reasons:** none

## Run verdicts

| Section | Verdict |
| --- | --- |
| Functional tests | passed |
| Lighthouse audits | completed |
| Performance thresholds | passed |

## Test outcomes

- Passed: 1
- Failed: 0
- Flaky: 0
- Skipped: 0

| Test | Status | Duration (ms) |
| --- | --- | --- |
| sauce-demo-journey.spec.js > SauceDemo UI performance journey > single-user purchase journey with browser metrics | passed | 3940 |

## Browser metrics (Playwright, browser-observed)

| Metric | Value | Available |
| --- | --- | --- |
| FCP (ms) | 400 | true |
| LCP (ms) | 548 | true |
| CLS | 0.0021591593424479167 | true |
| TTFB approx (ms) | 105.59999999403954 | true |
| DNS lookup (ms) | 7 | true |
| TCP connect (ms) | 57.5 | true |

### Interaction timings

| Interaction | Duration (ms) |
| --- | --- |
| goto-login-page | 403 |
| login-to-inventory-ready | 123 |
| add-to-cart-to-badge-updated | 61 |
| open-cart-to-item-verified | 90 |
| open-checkout-form | 51 |
| checkout-form-to-overview | 70 |
| checkout-submit-to-confirmation-visible | 55 |
| total-journey-duration | 3659 |

> These are custom click-to-visible measurements, NOT INP. INP is not measured.

> Checkpoints reached by client-side route change (no new document load): inventory, cart, checkout-form, checkout-overview, confirmation. Navigation timing and FCP apply only to the initial document; the per-step cost of those checkpoints is in the interaction timings above.

## Lighthouse (lab audit, per page)

- Lighthouse execution: ok (completion, not score quality)
- Outcomes: ok=3 failed=0 skipped=0 of 3
- Lowest performance score: 71/100 (informational; not gated)

| Page | Status | Auth | Performance | Accessibility | Best practices | SEO |
| --- | --- | --- | --- | --- | --- | --- |
| login | ok | no | 0.71 | 1 | 0.77 | 0.63 |
| product-detail | ok | yes | 0.96 | 1 | 0.73 | 0.66 |
| cart | ok | yes | 0.97 | 1 | 0.77 | 0.66 |


Lighthouse version: 13.5.0

> Lab audit - not real-user monitoring; not comparable to journey timings. A partial run (skipped pages) is not complete success.

## Performance thresholds

- lcpMs: actual=548 max=2500 -> passed
- cls: actual=0.0021591593424479167 max=0.1 -> passed
- journeyMs: actual=3659 max=8000 -> passed

## Report artifacts

- dashboard: `reports/dashboard.html`
- playwrightHtml: `reports/playwright/html`
- playwrightJson: `reports/playwright/results.json`
- junitXml: `reports/junit/results.xml`
- browserMetrics: `reports/browser-metrics/browser-metrics.json`
- lighthouseReports: `reports/lighthouse`
- lighthouseSummary: `reports/lighthouse/summary.json`

## Baseline comparison

| Metric | Baseline | Current | Delta | Change % | Verdict |
| --- | --- | --- | --- | --- | --- |
| LCP (ms) | 804 | 548 | -256 | -31.84 | improvement |
| CLS | 0.002 | 0.002 | 0 | 0 | within-noise |
| FCP (ms) | 604 | 400 | -204 | -33.77 | improvement |

> `within-noise` and `inconclusive` are not regressions. A single noisy run is never reported as a regression.

## Notes & limitations

- Single-user browser POC; complements JMeter, does not replace load/stress/soak testing.
- A single local run is not statistically reliable performance evidence.
- Browser-observed timings differ from server-side and Lighthouse lab metrics.

## Troubleshooting

- No failures recorded for this run.

